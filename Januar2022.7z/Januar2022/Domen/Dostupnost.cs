﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Dostupnost
    {
        public int RB { get; set; }
        public int IgraID { get; set; }

        public string Platforma { get; set; }

        public string Status { get; set; }

        public DateTime DatumObjave { get; set; }

        public override bool Equals(object obj)
        {
            return obj is Dostupnost dostupnost &&
                   RB == dostupnost.RB &&
                   IgraID == dostupnost.IgraID;
        }

        
    }
}
