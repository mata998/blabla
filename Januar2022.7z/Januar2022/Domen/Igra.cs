﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Igra
    {
        public int IgraID { get; set; }

        public string Naziv { get; set; }

        public string Zanr { get; set; }

        public string Opis { get; set; }

        public string Korisnik { get; set; }

        public int IzdavacID { get; set; }

        public BindingList<Dostupnost> ListaDostupnosti { get; set; }

    }


}
