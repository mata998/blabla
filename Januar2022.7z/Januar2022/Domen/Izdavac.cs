﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domen
{
    [Serializable]
    public class Izdavac
    {
        public int IzdavacID { get; set; }

        public string Naziv { get; set; }

        public string Adresa { get; set; }

        public string URL { get; set; }

        public override string ToString()
        {
            return Naziv;
        }
    }
}
