﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;
using Proba4;

namespace Klijent
{
    public partial class FormMain : Form
    {
        private string username;
        public BindingList<Dostupnost> listaDostupnosti = new BindingList<Dostupnost>();
        public int igraId;

        public FormMain(string username)
        {
            InitializeComponent();
            this.username = username;
            cmbIzdavac.DataSource = Komunikacija.Instance.vratiIzdavace();

            BindingList<string> zanrovi = new BindingList<string>() {"Akcija","Avantura","RPG", 
                "Simulacija","Stategija","Ostalo" };

            cmbZanr.DataSource = zanrovi;

            dgv.DataSource = listaDostupnosti;

        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            FormaDostupnost fd = new FormaDostupnost(igraId, listaDostupnosti);
            fd.ShowDialog();
        }

        private void btnGenerisiID_Click(object sender, EventArgs e)
        {

            igraId = Komunikacija.Instance.generisiID();
            txtIgra.Text = igraId.ToString();

        }

        private void btnObrisi_Click(object sender, EventArgs e)
        {

            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Izaberite red");
                return;
            }

            DataGridViewSelectedRowCollection listaIzabranih = dgv.SelectedRows;


            foreach (DataGridViewRow red in listaIzabranih)
            {
                listaDostupnosti.Remove((Dostupnost) red.DataBoundItem);
            }

        }

        private void btnIzmeni_Click(object sender, EventArgs e)
        {

            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Izaberite red");
                return;
            }

            Dostupnost selektovanaDostupnost = (Dostupnost) dgv.SelectedRows[0].DataBoundItem;

            FormaDostupnost fd = new FormaDostupnost(igraId, listaDostupnosti, selektovanaDostupnost);
            fd.ShowDialog();

            dgv.Refresh();
        }

        int pojavljivanjePlatforme(string platforma)
        {
            int brojac = 0;

            foreach (Dostupnost dostupnost in listaDostupnosti)
            {
                if (dostupnost.Platforma == platforma)
                {
                    brojac++;
                }
            }

            return brojac;
        }

        private void btnSacuvaj_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtIgra.Text) ||
                    string.IsNullOrEmpty(txtNaziv.Text) ||
                    string.IsNullOrEmpty(txtOpis.Text)
                    )
                {
                    MessageBox.Show("Popunite polja");
                    return;
                }

                if (listaDostupnosti.Count == 0)
                {
                    MessageBox.Show("Dodajte dostupnost");
                    return;
                }

                foreach (Dostupnost dostupnost in listaDostupnosti)
                {
                    int broj = pojavljivanjePlatforme(dostupnost.Platforma);
                    if (broj > 1)
                    {
                        MessageBox.Show("Samo jedna dostupnost");
                        return;
                    }
                }



                int igraId = int.Parse(txtIgra.Text);
                string naziv = txtNaziv.Text;
                string opis =  txtOpis.Text;
                Izdavac izdavac = (Izdavac) cmbIzdavac.SelectedItem;
                string zanr = (string) cmbZanr.SelectedItem;



                Igra igra = new Igra()
                {
                    IgraID = igraId,
                    Naziv = naziv,
                    Opis = opis,
                    IzdavacID = izdavac.IzdavacID,
                    Zanr = zanr,
                    Korisnik = username,
                    ListaDostupnosti = listaDostupnosti
                };

                if (Komunikacija.Instance.sacuvajIgru(igra))
                {
                    MessageBox.Show("Uspesno sacuvana igra");
                }
                else
                {
                    MessageBox.Show("Neuspesno");
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Neuspesno");
            }


        }
    }
}
