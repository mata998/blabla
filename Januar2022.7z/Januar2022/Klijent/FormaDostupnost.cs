﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;

namespace Klijent
{
    public partial class FormaDostupnost : Form
    {

        public BindingList<Dostupnost> listaDostupnosti;
        public int igraId;
        private Dostupnost selektovanaDostupnost;
        public bool izmena = false;

        public FormaDostupnost(int igraId, BindingList<Dostupnost> listaDostupnosti)
        {
            InitializeComponent();

            this.igraId = igraId;
            this.listaDostupnosti = listaDostupnosti;

            BindingList<string> platforma = new BindingList<string>() {"PC","Playstation","XBOX",
                "Stream" };

            cmbPlatforma.DataSource = platforma;

            BindingList<string> status = new BindingList<string>() {"Aktivna","U razvoju","Arhivirana"};

            cmbStatus.DataSource = status;

        }

        public FormaDostupnost(int igraId, BindingList<Dostupnost> listaDostupnosti, Dostupnost selektovanaDostupnost)
        {
            InitializeComponent();

            this.igraId = igraId;
            this.listaDostupnosti = listaDostupnosti;
            this.selektovanaDostupnost = selektovanaDostupnost;

            BindingList<string> platforma = new BindingList<string>() {"PC","Playstation","XBOX",
                "Stream" };

            cmbPlatforma.DataSource = platforma;

            BindingList<string> status = new BindingList<string>() { "Aktivna", "U razvoju", "Arhivirana" };

            cmbStatus.DataSource = status;


            textBox1.Text = selektovanaDostupnost.DatumObjave.ToString("d.M.yyyy");
            cmbStatus.SelectedItem = selektovanaDostupnost.Status;
            cmbPlatforma.SelectedItem = selektovanaDostupnost.Platforma;
            button1.Text = "Izmeni dostupnost";
            izmena = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    MessageBox.Show("Popunite datum");
                    return;
                }

                string platforma = (string)cmbPlatforma.SelectedItem;
                string status = (string)cmbStatus.SelectedItem;
                DateTime datum = DateTime.ParseExact(textBox1.Text, "d.M.yyyy", CultureInfo.InvariantCulture);
                int redniBroj = listaDostupnosti.Count + 1;



                if (!izmena)
                {
                    Dostupnost dostupnost = new Dostupnost()
                    {
                        RB = redniBroj,
                        IgraID = igraId,
                        Platforma = platforma,
                        Status = status,
                        DatumObjave = datum
                    };

                    listaDostupnosti.Add(dostupnost);
                }
                else
                {
                    selektovanaDostupnost.Platforma = platforma;
                    selektovanaDostupnost.Status = status;
                    selektovanaDostupnost.DatumObjave = datum;
                }

                this.Visible = false;
            }
            catch (Exception)
            {
                MessageBox.Show("popunite formu lepo");
            }
        }
    }
}
