﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Domen;
using Proba4;

namespace Klijent
{
    class Komunikacija
    {
        private Komunikacija() { }

        private static Komunikacija instance;

        public static Komunikacija Instance
        {
            get
            {

                if (instance == null) instance = new Komunikacija();
                return instance;

            }



        }

        public List<Izdavac> vratiIzdavace()
        {
            Zahtev z = new Zahtev();
            z.Opcija = Opcija.vratiSveIzdavace;
            formatter.Serialize(tok, z);
            Odgvor o = (Odgvor)formatter.Deserialize(tok);
            return (List<Izdavac>)o.Objekat;
        }

        public int generisiID()
        {
            Zahtev z = new Zahtev();
            z.Opcija = Opcija.vratiMaxID;
            formatter.Serialize(tok, z);

            Odgvor o = (Odgvor)formatter.Deserialize(tok);
            return (int)o.Objekat;
        }



        Socket serverskiSoket;
        BinaryFormatter formatter;
        NetworkStream tok;

        public void Povezi() {

            try
            {
                serverskiSoket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                serverskiSoket.Connect("127.0.0.1", 9999);
                formatter = new BinaryFormatter();
                tok = new NetworkStream(serverskiSoket);

            }
            catch (Exception)
            {

                throw;
            }






        }

       


        public List<Korisnik> useri = new List<Korisnik>() {

            new Korisnik(){Username="andj",Password="andj"},
            new Korisnik(){Username="mata",Password="mata"},
            new Korisnik(){Username="vili",Password="vili"}

        };
        public Korisnik Login(string username, string password) {

            try
            {
              

                foreach (Korisnik u in useri)
                {
                    if (u.Username == username && u.Password == password)
                    {
                        return u;
                    }

                }

                return null;


            }
            catch (Exception)
            {

                return null;
                throw;
            }
           

        
        
        
        }

        public bool sacuvajIgru(Igra igra)
        {

            Zahtev z = new Zahtev();
            z.Opcija = Opcija.sacuvajIgru;
            z.Objekat = igra;

            formatter.Serialize(tok, z);

            Odgvor o = (Odgvor)formatter.Deserialize(tok);

            return o.Uspesno;
        }
    }
}
