﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domen;


namespace Klijent
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            Komunikacija.Instance.Povezi();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUser.Text;
            string password = txtPass.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Popunite polja");
                return;
            }

            Korisnik user = Komunikacija.Instance.Login(username, password);

            if (user != null)
            {
                FormMain frm = new FormMain(user.Username);

                this.Visible = false;

                frm.ShowDialog();
                frm.Visible = true;
            }
            else
            {
                MessageBox.Show("Korisnik ne postoji");
            }

        }
    }
}
