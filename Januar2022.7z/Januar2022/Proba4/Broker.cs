﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domen;

namespace Proba4
{
    public class Broker
    {
        SqlConnection connection;
        SqlTransaction transaction;
        private Broker() {

            connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ProSoft-Januar2022;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
      
        }

        private static Broker instance;

        public static Broker Instance
        {
            get
            {

                if (instance == null) instance = new Broker();
                return instance;

            }


        }


        public List<Korisnik> vratiSveUsere() {


            try
            {
                List<Korisnik> useri = new List<Korisnik>(); ;
                connection.Open();
                SqlCommand komanda = new SqlCommand("", connection);
                komanda.CommandText = "select * from Kor";
                SqlDataReader reader = komanda.ExecuteReader();
                while (reader.Read())
                {
                    Korisnik u = new Korisnik
                    {
                        Username = (string)reader[1],
                        Password = (string)reader[2]
                    };

                    useri.Add(u);

                }

                return useri;

            }
            catch (Exception)
            {
                connection.Close();
                return null;
                throw;
            }

            finally {

                connection.Close();
            }










        }

        public bool sacuvajIgru(Igra igra)
        {
            try
            {
                connection.Open();
                transaction = connection.BeginTransaction();

                SqlCommand komanda = new SqlCommand("", connection);

                komanda.CommandText = "insert into Igra " +
                    "values(@igraid, @naziv, @zanr, @opis, @korisnik, @izdavacid)";

                komanda.Transaction = transaction;

                komanda.Parameters.AddWithValue("@igraid", igra.IgraID);
                komanda.Parameters.AddWithValue("@naziv", igra.Naziv);
                komanda.Parameters.AddWithValue("@zanr", igra.Zanr);
                komanda.Parameters.AddWithValue("@opis", igra.Opis);
                komanda.Parameters.AddWithValue("@korisnik", igra.Korisnik);
                komanda.Parameters.AddWithValue("@izdavacid", igra.IzdavacID);

                komanda.ExecuteNonQuery();

                foreach (Dostupnost dostupnost in igra.ListaDostupnosti)
                {
                    SqlCommand drugaKomanda = new SqlCommand("", connection);

                    drugaKomanda.Transaction = transaction;
                    drugaKomanda.CommandText = "insert into Dostupnost " +
                        "values(@igraid, @rb, @platforma, @datum, @status)";

                    drugaKomanda.Parameters.AddWithValue("@rb", dostupnost.RB);
                    drugaKomanda.Parameters.AddWithValue("@igraid", dostupnost.IgraID);
                    drugaKomanda.Parameters.AddWithValue("@status", dostupnost.Status);
                    drugaKomanda.Parameters.AddWithValue("@platforma", dostupnost.Platforma);
                    drugaKomanda.Parameters.AddWithValue("@datum", dostupnost.DatumObjave);

                    drugaKomanda.ExecuteNonQuery();
                }

                transaction.Commit();

                return true;
            }
            catch (Exception)
            {

                transaction.Rollback();
                connection.Close();
                
                return false;

            }
            finally
            {
                connection.Close();
            }
        }

        public List<Izdavac> vratiSveIzdavace() {

            try
            {
                List<Izdavac> izdavaci = new List<Izdavac>();
                connection.Open();
                SqlCommand komanda = new SqlCommand("", connection);
                komanda.CommandText = "select * from Izdavac";
                SqlDataReader reader = komanda.ExecuteReader();
                while (reader.Read())
                {

                    izdavaci.Add(new Izdavac()
                    {

                        IzdavacID = (int)reader[0],
                        Naziv = (string)reader[1],
                        Adresa = (string)reader[2],
                        URL = (string)reader[3]



                    });

                }

                return izdavaci;


            }
            catch (Exception)
            {
                connection.Close();
                return null;
            }
            finally {

                connection.Close();
            
            }
        
        
        
        
        
        }

        public int generisiIgraID() {

            try
            {
                int maxID = 1;
                connection.Open();
                SqlCommand komanda = new SqlCommand("", connection);
                komanda.CommandText = "select max(IgraID) from Igra";
  
                SqlDataReader reader = komanda.ExecuteReader();

                reader.Read();

                if (reader[0] is DBNull)
                {
                    return 1;
                }

                maxID = (int)reader[0];


                return maxID + 1;


            }
            catch (Exception)
            {
                connection.Close();
                throw;
            }
            finally
            {

                connection.Close();

            }












        }
    }
}
