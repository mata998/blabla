﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domen;

namespace Proba4
{
    public class Broker
    {
        SqlConnection connection;
        private Broker() {

            connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Proba4;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
      
        }

        private static Broker instance;

        public static Broker Instance
        {
            get
            {

                if (instance == null) instance = new Broker();
                return instance;

            }


        }


        public List<User> vratiSveUsere() {


            try
            {
                List<User> useri = new List<User>(); ;
                connection.Open();
                SqlCommand komanda = new SqlCommand("", connection);
                komanda.CommandText = "select * from Kor";
                SqlDataReader reader = komanda.ExecuteReader();
                while (reader.Read())
                {
                    User u = new User
                    {
                        Username = (string)reader[1],
                        Password = (string)reader[2]
                    };

                    useri.Add(u);

                }

                return useri;

            }
            catch (Exception)
            {
                connection.Close();
                return null;
               
            }

            finally {

                connection.Close();
            }










        }



    }
}
