﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Domen;

namespace Proba4
{
   public class Obrada
    {
        private Socket klijentskiSocket;
        private List<Socket> listaSoketa;
        private BinaryFormatter formater;
        private NetworkStream tok;

        public Obrada(Socket klijentskiSocket, List<Socket> listaSoketa)
        {
            this.klijentskiSocket = klijentskiSocket;
            this.listaSoketa = listaSoketa;
            formater = new BinaryFormatter();
            tok = new NetworkStream(klijentskiSocket);
        }

        internal void Obradi()
        {

            try
            {
                while (true)
                {
                    Zahtev zahtev = (Zahtev)formater.Deserialize(tok);
                    Odgvor od = new Odgvor();
                    switch (zahtev.Opcija)
                    {
                        case Opcija.Login:
                            List<User> useri = Broker.Instance.vratiSveUsere();
                            od.Objekat = useri;
                            formater.Serialize(tok, od);
                            break;
                        case Opcija.DrugaOp:
                            break;
                        case Opcija.TrecaOp:
                            break;
                        default:
                            break;
                    }
                }
               

            }
            catch (Exception)
            {
                klijentskiSocket.Close();
                Environment.Exit(0);
                throw;
            }





        }
    }
}
