﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Proba4
{
    public class Server
    {
        private Server() { }

        private static Server instance;

        public static Server Instance
        {
            get {

                if (instance == null) instance = new Server();
                return instance;
            
            }
        
        
        
        }

        Socket osluskujuciSoket;
        List<Socket> listaSoketa = new List<Socket>();

        public bool PokreniServer() {

            try
            {
                osluskujuciSoket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint par = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 9999);
                osluskujuciSoket.Bind(par);
                osluskujuciSoket.Listen(5);
                Thread t = new Thread(Osluskuj);
                t.Start();

                
                listaSoketa.Add(osluskujuciSoket);

                return true;

            }
            catch (Exception)
            {
                return false;
                throw;
                
            }
        
        
        
        
        
        
        
        
        
        }

        public bool ZatvoriServer() {

            try
            {

                foreach (Socket s in listaSoketa)
                {
                    s.Close();
                }
                return true;
            }
            catch (Exception)
            {
                return false;

                throw;
            }
        
        
        
        
        
        
        
        }

        private void Osluskuj()
        {
            try
            {
                while (true)
                {
                    Socket klijentskiSocket = osluskujuciSoket.Accept();
                    Obrada obrada = new Obrada(klijentskiSocket, listaSoketa);
                    new Thread(() => obrada.Obradi()).Start();
                    listaSoketa.Add(klijentskiSocket);

                }

            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }
}
